# PassaTempoDuelm

Protótipo Android de jogo de luta 2D feito para partidas rápidas.

## Já incluído

- 2 personagens selecionáveis: VEX e ROOK.
- Arena 2D desenhada em Jetpack Compose.
- Controles touch para andar e atacar.
- Barra de vida e vitória por nocaute.
- Modo local de treino.
- Base de rede direta com o próprio celular hospedando na porta TCP 7777.
- Tela para hospedar ou entrar pelo IP.
- GitHub Actions para gerar APK de debug automaticamente.

## Abrir no Android Studio

1. Extraia a pasta.
2. No Android Studio, escolha **Open** e selecione a pasta `PassaTempoDuelm`.
3. Aguarde o Gradle sincronizar.
4. Execute no celular.

## APK pelo GitHub

Depois de enviar o conteúdo para o repositório, a action **Build Android APK** roda automaticamente. O APK fica nos artefatos do workflow com o nome `PassaTempoDuelm-debug`.

## Sobre o online fora do mesmo Wi‑Fi

O protótipo abre um servidor TCP no próprio celular na porta 7777. Ele funciona entre redes diferentes quando o celular host possui um endereço alcançável e a porta está liberada. Em muitas operadoras móveis há CGNAT, que bloqueia conexões de entrada. Para funcionar de forma confiável em qualquer rede sem Tailscale, a próxima evolução é incluir um pequeno relay público ou uma camada WebRTC/TURN.

## Próximos passos sugeridos

- Sprites/arte final inspirados na referência escolhida.
- Animações de soco, chute, defesa e pulo.
- Sincronização online autoritativa completa.
- Som, vibração e efeitos de impacto.
- Tela de sala/código para conectar sem digitar IP.
