# Regras customizadas podem ser adicionadas aqui no futuro.
