package com.passatempo.duel.network

import android.os.Handler
import android.os.Looper
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

class DirectDuelNetwork {
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var serverSocket: ServerSocket? = null
    @Volatile private var socket: Socket? = null
    @Volatile private var writer: BufferedWriter? = null
    @Volatile private var messageListener: ((String) -> Unit)? = null

    fun startHost(
        port: Int = 7777,
        onConnected: () -> Unit,
        onMessage: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        close()
        thread(name = "duel-host") {
            try {
                serverSocket = ServerSocket(port)
                val accepted = serverSocket!!.accept()
                socket = accepted
                setupStreams(accepted, onConnected, onMessage, onError)
            } catch (e: Exception) {
                if (serverSocket?.isClosed != true) post { onError(e.message ?: "Falha ao hospedar") }
            }
        }
    }

    fun connect(
        host: String,
        port: Int = 7777,
        onConnected: () -> Unit,
        onMessage: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        close()
        thread(name = "duel-client") {
            try {
                val connected = Socket(host, port)
                socket = connected
                setupStreams(connected, onConnected, onMessage, onError)
            } catch (e: Exception) {
                post { onError(e.message ?: "Falha ao conectar") }
            }
        }
    }

    private fun setupStreams(
        connected: Socket,
        onConnected: () -> Unit,
        onMessage: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        writer = BufferedWriter(OutputStreamWriter(connected.getOutputStream()))
        messageListener = onMessage
        val reader = BufferedReader(InputStreamReader(connected.getInputStream()))
        post(onConnected)

        try {
            while (!connected.isClosed) {
                val line = reader.readLine() ?: break
                post { messageListener?.invoke(line) }
            }
        } catch (e: Exception) {
            if (!connected.isClosed) post { onError(e.message ?: "Conexão encerrada") }
        }
    }

    fun setMessageListener(listener: (String) -> Unit) {
        messageListener = listener
    }

    fun send(message: String) {
        thread(name = "duel-send") {
            try {
                val activeWriter = writer ?: return@thread
                synchronized(activeWriter) {
                    activeWriter.write(message)
                    activeWriter.newLine()
                    activeWriter.flush()
                }
            } catch (_: Exception) {
            }
        }
    }

    fun close() {
        try { writer?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        try { serverSocket?.close() } catch (_: Exception) {}
        writer = null
        socket = null
        serverSocket = null
        messageListener = null
    }

    private fun post(block: () -> Unit) = mainHandler.post(block)
}
