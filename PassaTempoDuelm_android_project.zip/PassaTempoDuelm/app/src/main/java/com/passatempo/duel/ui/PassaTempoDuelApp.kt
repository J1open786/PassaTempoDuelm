package com.passatempo.duel.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.passatempo.duel.network.DirectDuelNetwork
import kotlin.math.abs

private enum class Screen { MENU, SELECT, ONLINE, FIGHT }
private enum class GameMode { LOCAL, ONLINE }

data class Fighter(val name: String, val subtitle: String, val body: Color)

private val fighters = listOf(
    Fighter("VEX", "Rápido e agressivo", Color(0xFFE53935)),
    Fighter("ROOK", "Pesado e resistente", Color(0xFF5C6BC0))
)

@Composable
fun PassaTempoDuelApp() {
    MaterialTheme(colorScheme = darkColorScheme()) {
        val network = remember { DirectDuelNetwork() }
        var screen by remember { mutableStateOf(Screen.MENU) }
        var mode by remember { mutableStateOf(GameMode.LOCAL) }
        var selected by remember { mutableIntStateOf(0) }
        var isHost by remember { mutableStateOf(false) }

        DisposableEffect(Unit) {
            onDispose { network.close() }
        }

        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0xFF080A0F))
                .systemBarsPadding()
        ) {
            when (screen) {
                Screen.MENU -> MenuScreen(
                    onLocal = {
                        mode = GameMode.LOCAL
                        screen = Screen.SELECT
                    },
                    onOnline = {
                        mode = GameMode.ONLINE
                        screen = Screen.SELECT
                    }
                )

                Screen.SELECT -> CharacterSelectScreen(
                    selected = selected,
                    onSelected = { selected = it },
                    onBack = { screen = Screen.MENU },
                    onContinue = {
                        screen = if (mode == GameMode.ONLINE) Screen.ONLINE else Screen.FIGHT
                    }
                )

                Screen.ONLINE -> OnlineLobbyScreen(
                    network = network,
                    onBack = {
                        network.close()
                        screen = Screen.SELECT
                    },
                    onConnected = { host ->
                        isHost = host
                        screen = Screen.FIGHT
                    }
                )

                Screen.FIGHT -> FightScreen(
                    localFighter = fighters[selected],
                    remoteFighter = fighters[1 - selected],
                    network = if (mode == GameMode.ONLINE) network else null,
                    isHost = isHost,
                    onExit = {
                        network.close()
                        screen = Screen.MENU
                    }
                )
            }
        }
    }
}

@Composable
private fun MenuScreen(onLocal: () -> Unit, onOnline: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("PASSATEMPO DUEL", fontSize = 34.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp))
        Text("Luta rápida. Dois personagens. Sem enrolação.", color = Color.LightGray)
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            BigButton("LUTA LOCAL", onLocal)
            BigButton("ONLINE", onOnline)
        }
    }
}

@Composable
private fun BigButton(text: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.width(190.dp).height(58.dp)) {
        Text(text, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CharacterSelectScreen(
    selected: Int,
    onSelected: (Int) -> Unit,
    onBack: () -> Unit,
    onContinue: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Text("ESCOLHA SEU LUTADOR", fontSize = 28.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(18.dp))
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            fighters.forEachIndexed { index, fighter ->
                FighterCard(
                    fighter = fighter,
                    selected = selected == index,
                    modifier = Modifier.weight(1f),
                    onClick = { onSelected(index) }
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            OutlinedButton(onClick = onBack) { Text("VOLTAR") }
            Button(onClick = onContinue) { Text("LUTAR") }
        }
    }
}

@Composable
private fun FighterCard(
    fighter: Fighter,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val borderColor = if (selected) Color.White else Color.DarkGray
    Button(
        onClick = onClick,
        modifier = modifier.fillMaxHeight().border(2.dp, borderColor, RoundedCornerShape(18.dp)),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF11151E)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            FighterPreview(fighter, Modifier.size(150.dp))
            Spacer(Modifier.height(12.dp))
            Text(fighter.name, fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text(fighter.subtitle, color = Color.LightGray)
        }
    }
}

@Composable
private fun FighterPreview(fighter: Fighter, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val cx = size.width / 2f
        drawCircle(fighter.body, radius = size.minDimension * .16f, center = Offset(cx, size.height * .22f))
        drawRoundRect(
            fighter.body,
            topLeft = Offset(cx - size.width * .12f, size.height * .36f),
            size = Size(size.width * .24f, size.height * .36f)
        )
        drawLine(fighter.body, Offset(cx - 18f, size.height * .68f), Offset(cx - 38f, size.height * .95f), 18f)
        drawLine(fighter.body, Offset(cx + 18f, size.height * .68f), Offset(cx + 38f, size.height * .95f), 18f)
        drawLine(fighter.body, Offset(cx - 20f, size.height * .43f), Offset(cx - 70f, size.height * .62f), 16f)
        drawLine(fighter.body, Offset(cx + 20f, size.height * .43f), Offset(cx + 70f, size.height * .62f), 16f)
    }
}

@Composable
private fun OnlineLobbyScreen(
    network: DirectDuelNetwork,
    onBack: () -> Unit,
    onConnected: (Boolean) -> Unit
) {
    var ip by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Escolha hospedar ou entrar em uma partida") }
    var busy by remember { mutableStateOf(false) }

    fun host() {
        busy = true
        status = "Servidor aberto na porta 7777. Aguardando adversário..."
        network.startHost(
            onConnected = { onConnected(true) },
            onMessage = {},
            onError = {
                busy = false
                status = "Erro: $it"
            }
        )
    }

    fun join() {
        if (ip.isBlank()) {
            status = "Digite o IP do celular que está hospedando."
            return
        }
        busy = true
        status = "Conectando a $ip:7777..."
        network.connect(
            host = ip.trim(),
            onConnected = { onConnected(false) },
            onMessage = {},
            onError = {
                busy = false
                status = "Erro: $it"
            }
        )
    }

    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("MODO ONLINE", fontSize = 30.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(10.dp))
        Text(status, textAlign = TextAlign.Center, color = Color.LightGray)
        Spacer(Modifier.height(22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { host() }, enabled = !busy) { Text("HOSPEDAR") }
            OutlinedTextField(
                value = ip,
                onValueChange = { ip = it },
                label = { Text("IP do host") },
                singleLine = true,
                modifier = Modifier.width(220.dp)
            )
            Button(onClick = { join() }, enabled = !busy) { Text("ENTRAR") }
        }
        Spacer(Modifier.height(18.dp))
        Text(
            "Funciona direto entre celulares quando o host é alcançável pela internet. Em redes móveis com CGNAT pode ser necessário um relay no futuro.",
            color = Color.Gray,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(max = 620.dp)
        )
        Spacer(Modifier.height(20.dp))
        OutlinedButton(onClick = onBack) { Text("VOLTAR") }
    }
}

@Composable
private fun FightScreen(
    localFighter: Fighter,
    remoteFighter: Fighter,
    network: DirectDuelNetwork?,
    isHost: Boolean,
    onExit: () -> Unit
) {
    var hostX by remember { mutableFloatStateOf(.25f) }
    var clientX by remember { mutableFloatStateOf(.75f) }
    var hostHp by remember { mutableIntStateOf(100) }
    var clientHp by remember { mutableIntStateOf(100) }
    var winner by remember { mutableStateOf<String?>(null) }

    val localIsHost = network == null || isHost
    val hostName = if (localIsHost) localFighter.name else remoteFighter.name
    val clientName = if (localIsHost) remoteFighter.name else localFighter.name

    fun applyMessage(msg: String) {
        val parts = msg.split(":")
        if (parts.size < 3) return
        when (parts[0]) {
            "POS" -> {
                val value = parts[2].toFloatOrNull() ?: return
                if (parts[1] == "H") hostX = value else clientX = value
            }
            "HP" -> {
                val value = parts[2].toIntOrNull() ?: return
                if (parts[1] == "H") {
                    hostHp = value
                    if (value == 0) winner = clientName
                } else {
                    clientHp = value
                    if (value == 0) winner = hostName
                }
            }
        }
    }

    DisposableEffect(network) {
        network?.setMessageListener(::applyMessage)
        onDispose { }
    }

    fun sendPos(role: String, value: Float) = network?.send("POS:$role:$value")
    fun sendHp(role: String, value: Int) = network?.send("HP:$role:$value")

    fun move(delta: Float) {
        if (winner != null) return
        if (localIsHost) {
            hostX = (hostX + delta).coerceIn(.08f, .92f)
            sendPos("H", hostX)
        } else {
            clientX = (clientX + delta).coerceIn(.08f, .92f)
            sendPos("C", clientX)
        }
    }

    fun attack() {
        if (winner != null) return
        if (abs(hostX - clientX) > .22f) return
        if (localIsHost) {
            clientHp = (clientHp - 10).coerceAtLeast(0)
            sendHp("C", clientHp)
            if (clientHp == 0) winner = localFighter.name
        } else {
            hostHp = (hostHp - 10).coerceAtLeast(0)
            sendHp("H", hostHp)
            if (hostHp == 0) winner = localFighter.name
        }
    }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            HealthBar(
                name = hostName,
                hp = hostHp,
                modifier = Modifier.weight(1f)
            )
            Text("  VS  ", fontWeight = FontWeight.Black)
            HealthBar(
                name = clientName,
                hp = clientHp,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onExit) { Text("SAIR") }
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 8.dp)
                .background(Color(0xFF151A23), RoundedCornerShape(14.dp))
                .border(1.dp, Color(0xFF303745), RoundedCornerShape(14.dp))
        ) {
            Arena(
                hostX = hostX,
                clientX = clientX,
                hostFighter = if (localIsHost) localFighter else remoteFighter,
                clientFighter = if (localIsHost) remoteFighter else localFighter
            )
            winner?.let {
                Surface(
                    modifier = Modifier.align(Alignment.Center),
                    color = Color.Black.copy(alpha = .82f),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text(
                        "$it VENCEU",
                        modifier = Modifier.padding(horizontal = 32.dp, vertical = 20.dp),
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ControlButton("◀") { move(-.05f) }
                ControlButton("▶") { move(.05f) }
            }
            Text(
                if (network == null) "TREINO LOCAL" else if (isHost) "HOST • porta 7777" else "CLIENTE",
                color = Color.Gray,
                fontSize = 12.sp
            )
            ControlButton("SOCO", attack)
        }
    }
}

@Composable
private fun HealthBar(name: String, hp: Int, modifier: Modifier = Modifier) {
    Column(modifier.padding(horizontal = 6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(name, fontWeight = FontWeight.Bold)
            Text("$hp")
        }
        LinearProgressIndicator(
            progress = { hp / 100f },
            modifier = Modifier.fillMaxWidth().height(8.dp)
        )
    }
}

@Composable
private fun ControlButton(text: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.height(52.dp).widthIn(min = 72.dp)) {
        Text(text, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun Arena(
    hostX: Float,
    clientX: Float,
    hostFighter: Fighter,
    clientFighter: Fighter
) {
    Canvas(Modifier.fillMaxSize()) {
        val ground = size.height * .82f
        drawLine(Color(0xFF505867), Offset(0f, ground), Offset(size.width, ground), 5f)
        drawCircle(Color(0xFF222A35), radius = size.width * .14f, center = Offset(size.width * .5f, size.height * .28f), style = Stroke(4f))
        drawArenaFighter(hostX, ground, hostFighter.body, facingRight = true)
        drawArenaFighter(clientX, ground, clientFighter.body, facingRight = false)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawArenaFighter(
    x: Float,
    ground: Float,
    color: Color,
    facingRight: Boolean
) {
    val px = size.width * x
    val bodyH = size.height * .28f
    val headR = size.height * .045f
    val top = ground - bodyH
    drawCircle(color, headR, Offset(px, top - headR * 1.3f))
    drawRoundRect(color, Offset(px - 18f, top), Size(36f, bodyH * .55f))
    drawLine(color, Offset(px - 8f, top + bodyH * .52f), Offset(px - 22f, ground), 12f)
    drawLine(color, Offset(px + 8f, top + bodyH * .52f), Offset(px + 22f, ground), 12f)
    val armDir = if (facingRight) 1f else -1f
    drawLine(color, Offset(px, top + bodyH * .2f), Offset(px + armDir * 55f, top + bodyH * .34f), 12f)
}
